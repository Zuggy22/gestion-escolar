# notas/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from alumnos.models import Alumno
from cursos.models import Curso          # ← Curso viene de la app cursos
from .models import Nota, Asistencia, ASIGNATURAS
from .forms import NotaForm, AsistenciaForm, AsistenciaMasivaForm
import datetime


# ─────────────────────────────────────────
# NOTAS
# ─────────────────────────────────────────

@login_required
def notas_alumno(request, alumno_pk):
    alumno = get_object_or_404(Alumno, pk=alumno_pk)
    notas  = Nota.objects.filter(alumno=alumno)

    promedios = [n.promedio_asignatura() for n in notas if n.promedio_asignatura() is not None]
    promedio_final = round(sum(promedios) / len(promedios), 1) if promedios else None

    if promedio_final:
        alumno.promedio = promedio_final
        alumno.save()

    return render(request, 'notas/notas_alumno.html', {
        'alumno':         alumno,
        'notas':          notas,
        'promedio_final': promedio_final,
    })


@login_required
def agregar_nota(request, alumno_pk):
    alumno = get_object_or_404(Alumno, pk=alumno_pk)

    if request.method == 'POST':
        formulario = NotaForm(request.POST)
        if formulario.is_valid():
            asignatura    = formulario.cleaned_data['asignatura']
            nota_existente = Nota.objects.filter(
                alumno=alumno,
                asignatura=asignatura
            ).first()

            if nota_existente:
                formulario = NotaForm(request.POST, instance=nota_existente)
                formulario.save()
                messages.success(request, f'✅ Notas de {asignatura} actualizadas.')
            else:
                nota        = formulario.save(commit=False)
                nota.alumno = alumno
                nota.save()
                messages.success(request, f'✅ Notas de {asignatura} registradas.')

            return redirect('notas:notas_alumno', alumno_pk=alumno.pk)
    else:
        formulario = NotaForm()

    return render(request, 'notas/agregar_nota.html', {
        'formulario': formulario,
        'alumno':     alumno,
    })


@login_required
def eliminar_nota(request, nota_pk):
    nota      = get_object_or_404(Nota, pk=nota_pk)
    alumno_pk = nota.alumno.pk
    if request.method == 'POST':
        asignatura = nota.asignatura
        nota.delete()
        messages.error(request, f'🗑️ Notas de {asignatura} eliminadas.')
        return redirect('notas:notas_alumno', alumno_pk=alumno_pk)
    return render(request, 'notas/confirmar_eliminar_nota.html', {'nota': nota})


@login_required
def promedio_curso(request, curso_nombre):
    alumnos = Alumno.objects.filter(curso=curso_nombre)

    datos_alumnos    = []
    promedios_validos = []

    for alumno in alumnos:
        notas     = Nota.objects.filter(alumno=alumno)
        promedios = [n.promedio_asignatura() for n in notas if n.promedio_asignatura()]
        prom      = round(sum(promedios) / len(promedios), 1) if promedios else None
        if prom:
            promedios_validos.append(prom)
        datos_alumnos.append({'alumno': alumno, 'promedio': prom})

    promedio_general = round(
        sum(promedios_validos) / len(promedios_validos), 1
    ) if promedios_validos else None

    return render(request, 'notas/promedio_curso.html', {
        'curso':            curso_nombre,
        'datos_alumnos':    datos_alumnos,
        'promedio_general': promedio_general,
        'total_alumnos':    alumnos.count(),
    })


@login_required
def resumen_cursos(request):
    cursos = Alumno.objects.values_list('curso', flat=True).distinct()

    datos_cursos = []
    for curso_nombre in cursos:
        if not curso_nombre:
            continue
        alumnos   = Alumno.objects.filter(curso=curso_nombre)
        promedios = []
        for alumno in alumnos:
            notas      = Nota.objects.filter(alumno=alumno)
            prom_notas = [n.promedio_asignatura() for n in notas if n.promedio_asignatura()]
            if prom_notas:
                promedios.append(round(sum(prom_notas) / len(prom_notas), 1))

        promedio_c = round(sum(promedios) / len(promedios), 1) if promedios else None
        datos_cursos.append({
            'curso':    curso_nombre,
            'promedio': promedio_c,
            'alumnos':  alumnos.count(),
        })

    datos_cursos.sort(key=lambda x: x['promedio'] or 0, reverse=True)

    return render(request, 'notas/resumen_cursos.html', {
        'datos_cursos': datos_cursos,
    })


# ─────────────────────────────────────────
# ASISTENCIA
# ─────────────────────────────────────────

@login_required
def registrar_asistencia(request, alumno_pk):
    alumno = get_object_or_404(Alumno, pk=alumno_pk)

    if request.method == 'POST':
        formulario = AsistenciaForm(request.POST)
        if formulario.is_valid():
            asignatura = formulario.cleaned_data['asignatura']
            fecha      = formulario.cleaned_data['fecha']
            estado     = formulario.cleaned_data['estado']

            asistencia, creada = Asistencia.objects.update_or_create(
                alumno=alumno,
                asignatura=asignatura,
                fecha=fecha,
                defaults={'estado': estado}
            )

            if creada:
                messages.success(request, f'✅ Asistencia del {fecha} en {asignatura} registrada.')
            else:
                messages.success(request, f'✅ Asistencia del {fecha} en {asignatura} actualizada.')

            return redirect('notas:asistencia_alumno', alumno_pk=alumno.pk)
    else:
        formulario = AsistenciaForm(initial={'fecha': datetime.date.today()})

    return render(request, 'notas/registrar_asistencia.html', {
        'formulario': formulario,
        'alumno':     alumno,
    })


@login_required
def asistencia_alumno(request, alumno_pk):
    alumno     = get_object_or_404(Alumno, pk=alumno_pk)
    asignaturas = [a[0] for a in ASIGNATURAS]

    resumen = []
    for asignatura in asignaturas:
        datos_asist   = Asistencia.porcentaje_asistencia(alumno, asignatura)
        nota_obj      = Nota.objects.filter(alumno=alumno, asignatura=asignatura).first()
        promedio_nota = nota_obj.promedio_asignatura() if nota_obj else None
        aprobacion    = Asistencia.estado_aprobacion(datos_asist['porcentaje'], promedio_nota)
        historial     = Asistencia.objects.filter(
            alumno=alumno, asignatura=asignatura
        ).order_by('-fecha')[:10]

        resumen.append({
            'asignatura':    asignatura,
            'porcentaje':    datos_asist['porcentaje'],
            'presentes':     datos_asist['presentes'],
            'total_clases':  datos_asist['total'],
            'promedio_nota': promedio_nota,
            'aprobacion':    aprobacion,
            'historial':     historial,
        })

    resumen_con_datos = [r for r in resumen if r['total_clases'] > 0 or r['promedio_nota']]

    return render(request, 'notas/asistencia_alumno.html', {
        'alumno':  alumno,
        'resumen': resumen_con_datos,
        'todas':   resumen,
    })


@login_required
def asistencia_curso(request, curso_nombre):
    alumnos = Alumno.objects.filter(curso=curso_nombre)

    if request.method == 'POST':
        asignatura = request.POST.get('asignatura')
        fecha_str  = request.POST.get('fecha')
        fecha      = datetime.date.fromisoformat(fecha_str)

        for alumno in alumnos:
            estado = request.POST.get(f'estado_{alumno.pk}', 'Ausente')
            Asistencia.objects.update_or_create(
                alumno=alumno,
                asignatura=asignatura,
                fecha=fecha,
                defaults={'estado': estado}
            )

        messages.success(
            request,
            f'✅ Asistencia del {fecha} en {asignatura} registrada para {alumnos.count()} alumnos.'
        )
        return redirect('notas:resumen_asistencia_curso', curso_nombre=curso_nombre)

    formulario = AsistenciaMasivaForm(initial={'fecha': datetime.date.today()})

    return render(request, 'notas/asistencia_curso.html', {
        'formulario':  formulario,
        'alumnos':     alumnos,
        'curso':       curso_nombre,
        'asignaturas': ASIGNATURAS,
        'hoy':         datetime.date.today().strftime('%Y-%m-%d'),
    })


@login_required
def resumen_asistencia_curso(request, curso_nombre):
    alumnos     = Alumno.objects.filter(curso=curso_nombre)
    asignaturas = [a[0] for a in ASIGNATURAS]

    datos = []
    for alumno in alumnos:
        materias               = []
        aprobadas = reprobadas = sin_datos = 0

        for asignatura in asignaturas:
            asist      = Asistencia.porcentaje_asistencia(alumno, asignatura)
            nota_obj   = Nota.objects.filter(alumno=alumno, asignatura=asignatura).first()
            promedio   = nota_obj.promedio_asignatura() if nota_obj else None
            aprobacion = Asistencia.estado_aprobacion(asist['porcentaje'], promedio)

            if aprobacion['estado'] == 'Aprobado':
                aprobadas += 1
            elif aprobacion['estado'] == 'Reprobado':
                reprobadas += 1
            else:
                sin_datos += 1

            materias.append({
                'asignatura': asignatura,
                'porcentaje': asist['porcentaje'],
                'promedio':   promedio,
                'aprobacion': aprobacion,
            })

        datos.append({
            'alumno':     alumno,
            'materias':   materias,
            'aprobadas':  aprobadas,
            'reprobadas': reprobadas,
            'sin_datos':  sin_datos,
        })

    return render(request, 'notas/resumen_asistencia_curso.html', {
        'datos':       datos,
        'curso':       curso_nombre,
        'asignaturas': asignaturas,
    })
@login_required
def resumen_asistencia_general(request):
    """Muestra todos los cursos disponibles para ver asistencia."""
    cursos = Alumno.objects.values_list('curso', flat=True).distinct()
    cursos = [c for c in cursos if c]
    return render(request, 'notas/resumen_asistencia_general.html', {
        'cursos': cursos,
    })