# notas/models.py
from django.db import models
from alumnos.models import Alumno


ASIGNATURAS = [
    ('Lenguaje',         'Lenguaje y Comunicación'),
    ('Matemáticas',      'Matemáticas'),
    ('Ciencias',         'Ciencias Naturales'),
    ('Historia',         'Historia y Geografía'),
    ('Inglés',           'Inglés'),
    ('Educación Física', 'Educación Física'),
    ('Artes',            'Artes Visuales'),
]


class Nota(models.Model):
    """
    Modelo que representa las notas de un alumno en una asignatura.
    Hasta 4 notas por asignatura. El promedio se calcula automáticamente.
    """
    alumno     = models.ForeignKey(
        Alumno,
        on_delete=models.CASCADE,
        related_name='notas'
    )
    asignatura = models.CharField(max_length=50, choices=ASIGNATURAS)
    nota_1     = models.DecimalField(max_digits=3, decimal_places=1, null=True, blank=True)
    nota_2     = models.DecimalField(max_digits=3, decimal_places=1, null=True, blank=True)
    nota_3     = models.DecimalField(max_digits=3, decimal_places=1, null=True, blank=True)
    nota_4     = models.DecimalField(max_digits=3, decimal_places=1, null=True, blank=True)

    class Meta:
        verbose_name        = 'Nota'
        verbose_name_plural = 'Notas'
        unique_together     = ['alumno', 'asignatura']
        ordering            = ['alumno', 'asignatura']

    def __str__(self):
        return f'{self.alumno} — {self.asignatura}'

    def promedio_asignatura(self):
        notas = [n for n in [self.nota_1, self.nota_2, self.nota_3, self.nota_4] if n is not None]
        if not notas:
            return None
        return round(sum(float(n) for n in notas) / len(notas), 1)

    def estado(self):
        prom = self.promedio_asignatura()
        if prom is None:
            return 'Sin notas'
        return 'Aprobado' if prom >= 5.5 else 'Reprobado'


class Asistencia(models.Model):
    """
    Registra la asistencia diaria de un alumno por asignatura.
    Lunes a Viernes — Estado: Presente o Ausente
    """
    ESTADOS = [
        ('Presente', 'Presente'),
        ('Ausente',  'Ausente'),
    ]

    alumno     = models.ForeignKey(
        Alumno,
        on_delete=models.CASCADE,
        related_name='asistencias'
    )
    asignatura = models.CharField(max_length=50, choices=ASIGNATURAS)
    fecha      = models.DateField()
    estado     = models.CharField(max_length=10, choices=ESTADOS, default='Presente')

    class Meta:
        verbose_name        = 'Asistencia'
        verbose_name_plural = 'Asistencias'
        unique_together     = ['alumno', 'asignatura', 'fecha']
        ordering            = ['-fecha', 'alumno', 'asignatura']

    def __str__(self):
        return f'{self.alumno} — {self.asignatura} — {self.fecha} — {self.estado}'

    @staticmethod
    def porcentaje_asistencia(alumno, asignatura):
        total = Asistencia.objects.filter(
            alumno=alumno,
            asignatura=asignatura
        ).count()

        presentes = Asistencia.objects.filter(
            alumno=alumno,
            asignatura=asignatura,
            estado='Presente'
        ).count()

        if total == 0:
            return {'porcentaje': None, 'presentes': 0, 'total': 0}

        porcentaje = round((presentes / total) * 100, 1)
        return {
            'porcentaje': porcentaje,
            'presentes':  presentes,
            'total':      total,
        }

    @staticmethod
    def estado_aprobacion(porcentaje_asist, promedio_nota):
        """
        Reglas de aprobación:
        - Asistencia >= 80% y nota >= 4.5 → APROBADO
        - Asistencia >= 70% y < 80% y nota >= 5.0 → APROBADO
        - De lo contrario → REPROBADO
        """
        if porcentaje_asist is None or promedio_nota is None:
            return {
                'estado':  'Sin datos',
                'color':   'slate',
                'emoji':   '⏳',
                'detalle': 'Faltan datos para evaluar'
            }

        if porcentaje_asist >= 80 and promedio_nota >= 4.5:
            return {
                'estado':  'Aprobado',
                'color':   'green',
                'emoji':   '✅',
                'detalle': f'Asistencia {porcentaje_asist}% ≥ 80% y nota {promedio_nota} ≥ 4.5'
            }
        elif 70 <= porcentaje_asist < 80 and promedio_nota >= 5.0:
            return {
                'estado':  'Aprobado',
                'color':   'green',
                'emoji':   '✅',
                'detalle': f'Asistencia {porcentaje_asist}% entre 70%-80% y nota {promedio_nota} ≥ 5.0'
            }
        else:
            return {
                'estado':  'Reprobado',
                'color':   'red',
                'emoji':   '❌',
                'detalle': f'Asistencia {porcentaje_asist}% y nota {promedio_nota} no cumplen requisitos'
            }